/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import cybercafe.DataBaseConnection;
import cybercafe.Login;
import cybercafe.TimeDetails;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Lenovo
 */
public class ServiceClass {
    int i=0;
    TimeDetails td = new TimeDetails();
    String idm = td.a;
   
    public void setTimer(int time)
    {
    new Thread(new Runnable(){
        
    @Override
        public void run(){
            try{
            for(int i=1;i<=time;i++)
            {
            Thread.sleep(1000);
            System.out.println(i);
            if(i==time)
            {
              System.out.println(idm);  
            System.out.println("Logout");
            JOptionPane.showMessageDialog(null, "alert");
          //  System.exit(0);
            try {
                 DataBaseConnection connection = new DataBaseConnection();
                  Connection con = connection.getConnection();
                  System.out.println(idm);  
                 // PreparedStatement ps = con.prepareStatement(" update pc_allocate set pc1='null',pc2='null',pc3='null',pc4='null',pc5='null' where id="+"idm");
                 
                 PreparedStatement ps = con.prepareStatement("delete from pc_allocation  where pc=?");
                 ps.setString(1, idm);
                 int rs=ps.executeUpdate();
                  
                  if(rs>0)
                  {
                      JOptionPane.showMessageDialog(null, "Upadted");
                  } 
                  else
                  {
                      JOptionPane.showMessageDialog(null, "something went wrong");
                      
                  } 
        }
        catch (SQLException ex) {
             Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
       }
          System.exit(0);
                
            }
            }
            
            }catch(InterruptedException ex){
              Logger.getLogger(ServiceClass.class.getName()).log(Level.SEVERE,null,ex);      
                    
            }
            
            
            }
        
            }).start();
    
    
    
    
    
    
    }
            
            
            
            
 }
    
