/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cybercafe;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import service.ServiceClass;

/**
 *
 * @author Lenovo
 */
public class UserAdmin {
    public void choose(){
        Login obj = new Login();
        System.out.println(obj.username);
        if(obj.username.equals("admin")){
            MenuPage menu = new MenuPage();
            menu.setVisible(true);
           
        }
       else{
           
                UserMenu mnu = new UserMenu();
                mnu.setVisible(true);
                ServiceClass amd = new ServiceClass();
                amd.setTimer(15);
                
                
               
        }
    }
    
}
