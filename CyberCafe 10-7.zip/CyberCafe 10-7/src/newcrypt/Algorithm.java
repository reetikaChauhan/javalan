/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newcrypt;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Lenovo
 */
public class Algorithm {
    /* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

 


    private BigInteger p;
    private BigInteger q;
    private BigInteger N;
    private BigInteger phi;
    private BigInteger e;
    private BigInteger d;
    private int bitlength = 128;
    private Random r;
 
    public Algorithm(){
        
    }
    
    public void generatePrimeNumber()
    {
        r = new Random();
        p = BigInteger.probablePrime(bitlength, r);
        q = BigInteger.probablePrime(bitlength, r);
        N = p.multiply(q);
        phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE));
        e = BigInteger.probablePrime(bitlength / 2, r);
        while (phi.gcd(e).compareTo(BigInteger.ONE) > 0 && e.compareTo(phi) < 0)
        {
            e.add(BigInteger.ONE);
        }
        d = e.modInverse(phi);
        System.out.println("private_key:"+d);
        System.out.println("random_key:"+N);
    }
 
    public Algorithm(BigInteger e, BigInteger d, BigInteger N)
    {
        this.e = e;
        this.d = d;
        this.N = N;
    }
    
    public BigInteger getp()
    {
        return( p ) ;
    }

    /**
    * Get prime number q.
    *
    * @return Prime number q.
    */
    public BigInteger getq()
    {
        return( q ) ;
    }

    /**
    * Get r.
    *
    * @return r.
    */
    public BigInteger getphi()
    {
        return( phi ) ;
    }

    /**
    * Get modulus N.
    *
    * @return Modulus N.
    */
    public BigInteger getN()
    {
    return( N ) ;
    }

    /**
    * Get Public exponent E.
    *
    * @return Public exponent E.
    */
    public BigInteger getE()
    {
    return( e ) ;
    }

    /**
    * Get Private exponent D.
    *
    * @return Private exponent D.
    */
    public BigInteger getD()
    {
        return( d ) ;
    }
 
    public static String bytesToString(byte[] encrypted)
    {
        String test = "";
        for (byte b : encrypted)
        {
            test += Byte.toString(b);
        }
        return test;
    }
    
    // Encrypt message
    public byte[] encrypt(String message,String pass)
    {   
        byte[] b=(new BigInteger(message.getBytes())).modPow(e, N).toByteArray();
        //insertDN(privateKey,randomNumber,pass);
        insertDN(d.toString(),N.toString(),pass);
        System.out.println("Encrypt:"+(new BigInteger(message.getBytes())).modPow(e, N).toByteArray());
        return b;
    }
 
    // Decrypt message

    /**
     *
     * @param message
     * @param d
     * @param N
     * @return
     */
        public byte[] decrypt(byte[] message,BigInteger d2,BigInteger N2)
    {
        System.out.println("Message :"+message.toString()+"\n key:"+d2.toString()+"\nRandom"+N2.toString());
         return (new BigInteger(message)).modPow(d2,N2).toByteArray();
    }
    
    public void insertDN(String D,String N,String pass)
    {
        try{
                try {
                    //1.Driver Registration
                    Class.forName("com.mysql.jdbc.Driver");
                } 
                catch (ClassNotFoundException ex) {
                    Logger.getLogger(Algorithm.class.getName()).log(Level.SEVERE, null, ex);
                }
                PreparedStatement ps;
                try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/security_project","root","")) {
                    ps = con.prepareStatement("insert into simple_text_encryption(private_key,random_key,password) value(?,?,?)");
                    ps.setString(1, d.toString());
                    ps.setString(2, N);
                    ps.setString(3, pass);
                    int k=ps.executeUpdate();
                    if(k>0)
                    {
                            System.out.println("values inserted  into the table");
                    }
                    else{
                            System.out.println("values not inserted  into the table");
                    }
                }
                ps.close();
        }
        catch(SQLException ae)
        {
                System.out.println(ae);
        }
    
}

public String fetchDN(String cipher,String pass){
    
    String result="",private_key,product_no;
    try{
                        try {
                            //1.Driver Registration

                            Class.forName("com.mysql.jdbc.Driver");
                        } catch (ClassNotFoundException ex) {
                            Logger.getLogger(Algorithm.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        PreparedStatement ps;
                        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/security_project","root","")) {
                            ps = con.prepareStatement("select * from simple_text_encryption where password='"+pass+"'");
                            ResultSet rst= ps.executeQuery();
                            if(rst.next()){

                                private_key=rst.getString(2);
                                System.out.println("private_key:"+private_key);
                                product_no=rst.getString(3);
                                System.out.println("product_no:"+product_no);


                                byte[] decoded = Base64.getDecoder().decode(cipher);
                                byte[] plaintext=decrypt(decoded,new BigInteger(private_key),new BigInteger(product_no));
                                System.out.println("Decrypting Bytes: " + bytesToString(plaintext));

                                result=new String(plaintext);
                                System.out.println("result:"+result);
                                ps = con.prepareStatement("delete from simple_text_encryption where password='"+pass+"'");
                                ps.executeUpdate();
                            }
                            else{
                                JOptionPane.showMessageDialog(null,"Sorry Data not found");
                            }
                        }
			ps.close();
		}
		catch(SQLException ae)
		{
			System.out.println(ae);
		}
    return result;
    
}
}
    
